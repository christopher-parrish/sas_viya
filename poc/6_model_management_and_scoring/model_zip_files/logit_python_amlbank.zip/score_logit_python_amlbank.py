import math
import pickle
import pandas as pd
import numpy as np
from pathlib import Path

import settings

with open(Path(settings.pickle_path) / "logit_python_amlbank.pickle", "rb") as pickle_model:
    model = pd.read_pickle(pickle_model)

def score(marital_status_single, checking_only_indicator, prior_ctr_indicator, address_change_2x_indicator, cross_border_trx_indicator, in_person_contact_indicator, linkedin_indicator, citizenship_country_risk, distance_to_employer, distance_to_bank):
    "Output: EM_CLASSIFICATION, EM_EVENTPROBABILITY"

    try:
        global model
    except NameError:
        with open(Path(settings.pickle_path) / "logit_python_amlbank.pickle", "rb") as pickle_model:
            model = pd.read_pickle(pickle_model)


    index=None
    if not isinstance(marital_status_single, pd.Series):
        index=[0]
    input_array = pd.DataFrame(
        {"marital_status_single": marital_status_single, "checking_only_indicator":
        checking_only_indicator, "prior_ctr_indicator": prior_ctr_indicator,
        "address_change_2x_indicator": address_change_2x_indicator,
        "cross_border_trx_indicator": cross_border_trx_indicator,
        "in_person_contact_indicator": in_person_contact_indicator,
        "linkedin_indicator": linkedin_indicator, "citizenship_country_risk":
        citizenship_country_risk, "distance_to_employer": distance_to_employer,
        "distance_to_bank": distance_to_bank}, index=index
    )
    prediction = model.predict_proba(input_array).tolist()

    # Check for numpy values and convert to a CAS readable representation
    if isinstance(prediction, np.ndarray):
        prediction = prediction.tolist()

    if input_array.shape[0] == 1:
        if prediction[0][1] > 0.5:
            EM_CLASSIFICATION = "1"
        else:
            EM_CLASSIFICATION = "0"
        return EM_CLASSIFICATION, prediction[0][1]
    else:
        df = pd.DataFrame(prediction)
        proba = df[1]
        classifications = np.where(df[1] > 0.5, '1', '0')
        return pd.DataFrame({'EM_CLASSIFICATION': classifications, 'EM_EVENTPROBABILITY': proba})